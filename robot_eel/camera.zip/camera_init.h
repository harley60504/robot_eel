#pragma once

bool initCamera();
